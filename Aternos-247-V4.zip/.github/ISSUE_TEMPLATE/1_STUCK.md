---
name: Help, I'm stuck!
about: Ask a question for *your* problems.
labels: invalid
---

## Software / version
<!-- EX: Paper / 1.19.2 -->


## Describe your problem
<!-- A clear and concise description of what your problem is. -->


## Expected behavior
<!-- A clear and concise description of what you expected to happen. -->


## Error screenshots
<!-- If applicable, add error screenshots from your Repl project console. -->


## Additional context
<!-- Add any other context about your problem here. -->