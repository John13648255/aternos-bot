import initBot from "./bot.ts";
import initWeb from "./web.ts";

initBot();
initWeb();